/**
 * クラスを補助するクラスをまとめたパッケージ
 * @version 1.0
 * @since 2016/04/18
 */
package com.internousdev.solare.util;
