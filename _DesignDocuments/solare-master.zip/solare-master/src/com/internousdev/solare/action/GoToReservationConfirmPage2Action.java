/**
 *
 */
package com.internousdev.solare.action;

import com.opensymphony.xwork2.ActionSupport;

/**
 * GoToReservationConfirmPage2Action
 *
 * @sinse 206/4/06
 * @version 1.0
 */
public class GoToReservationConfirmPage2Action extends ActionSupport {

	/**
	 * 生成されたシリアルナンバー
	 *
	 * @since 2016/04/18
	 * @version 1.0
	 */
	private static final long serialVersionUID = -1409562642142788826L;

	/**
	 * 実行メソッド
	 *
	 * @sinse 206/04/06
	 * @return result 結果
	 */
	public String execute() {
		String result = SUCCESS;
		return result;
	}

}
